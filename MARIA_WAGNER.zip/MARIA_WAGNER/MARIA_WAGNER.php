<!DOCTYPE html>
<html lang="en"> 
<head>
    <title><?php echo "Maria Wagner's Resume"; ?></title>
	
    <!-- Meta -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Maria Wagner's resume">
    <meta name="author" content="Maria Wagner">    
    <link rel="shortcut icon" href="favicon.ico"> 
    
    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900" rel="stylesheet">
    
    <!-- FontAwesome JS-->
	<script defer src="assets/fontawesome/js/all.min.js"></script>
       
    <!-- Theme CSS -->  
    <link id="theme-style" rel="stylesheet" href="assets/css/pillar-1.css">


</head> 

<body>
    <article class="resume-wrapper text-center position-relative">
	    <div class="resume-wrapper-inner mx-auto text-start bg-white shadow-lg">
		    <header class="resume-header pt-4 pt-md-0">
			    <div class="row">
				    <div class="col-block col-md-auto resume-picture-holder text-center text-md-start">
				        <img class="picture" src="assets/images/profile.jpg" alt="">
				    </div><!--//col-->
				    <div class="col">
					    <div class="row p-4 justify-content-center justify-content-md-between">
						    <div class="primary-info col-auto">
								<h1 class='name mt-0 mb-1 text-white text-uppercase text-uppercase'><?php echo "Maria Wagner"; ?></h1>
								<div class='title mb-3'><?php echo "CIT Undergraduate"; ?></div>
							    <ul class="list-unstyled">
								    <li class="mb-2"><a class="text-link" href="mailto:wagnerma14@gmail.com"><i class="far fa-envelope fa-fw me-2" data-fa-transform="grow-3"></i><?php echo "wagnerma14@gmail.com"; ?></a></li>
								    <li><a class="text-link" href="tel:8597508808"><i class="fas fa-mobile-alt fa-fw me-2" data-fa-transform="grow-6"></i><?php echo "859 750 8808"; ?></a></li>
							    </ul>
						    </div><!--//primary-info-->
						    <div class="secondary-info col-auto mt-2">
							    <ul class="resume-social list-unstyled">
					                <li class="mb-3"><a class="text-link" href="http://www.linkedin.com/in/maria-wagner-58363328a"><span class="fa-container text-center me-2"><i class="fab fa-linkedin-in fa-fw"></i></span><?php echo "linkedin.com/in/maria-wagner-58363328a"; ?></a></li>
					                <li class="mb-3"><a class="text-link" href="http://github.com/MariaWagn"><span class="fa-container text-center me-2"><i class="fab fa-github-alt fa-fw"></i></span><?php echo "github.com/MariaWagn"; ?></a></li>
					                <li><a class="text-link" href="http://localhost/nku/MARIA_WAGNER/MARIA_WAGNER.php"><span class="fa-container text-center me-2"><i class="fas fa-globe"></i></span><?php echo "MARIA_WAGNER.php"; ?></a></li>
							    </ul>
						    </div><!--//secondary-info-->
					    </div><!--//row-->
					    
				    </div><!--//col-->
			    </div><!--//row-->
		    </header>
		    <div class="resume-body p-5">
			    <section class="resume-section summary-section mb-5">
				    <h2 class="resume-section-title text-uppercase font-weight-bold pb-3 mb-3"><?php echo "Summary"; ?></h2>
				    <div class="resume-section-content">
					    <p class="mb-0"><?php echo "I'm a fourth year at Northern Kentucky University. My major is computer information technology, with a minor in library informatics. I was a grader for the Unix systems course during the spring term of 2022. Currently, I'm working on a Capstone Project with the makerspace coordinator at NKU."; ?></p>
				    </div>
			    </section><!--//summary-section-->
			    <div class="row">
				    <div class="col-lg-9">
					    <section class="resume-section experience-section mb-5">
						    <h2 class="resume-section-title text-uppercase font-weight-bold pb-3 mb-3"><?php echo "Work Experience"; ?></h2>
						    <div class="resume-section-content">
							    <div class="resume-timeline position-relative">
								    <article class="resume-timeline-item position-relative pb-5">
									    
									    <div class="resume-timeline-item-header mb-2">
										    <div class="d-flex flex-column flex-md-row">
												<h3 class="resume-position-title font-weight-bold mb-1"><?php echo "Course Grader"; ?></h3>
										        <div class="resume-company-name ms-auto"><?php echo "Northern Kentucky University"; ?></div>
										    </div><!--//row-->
										    <div class="resume-position-time"><?php echo "January 2022 - May 2022"; ?></div>
									    </div><!--//resume-timeline-item-header-->
									    <div class="resume-timeline-item-desc">
										    <p><?php echo "As a course grader, I would grade students' labs and assignments for the professor. I would also assist students if they had questions or needed help."; ?></p>
										    <h4 class="resume-timeline-item-desc-heading font-weight-bold"><?php echo "Technologies used:"; ?></h4>
										    <ul class="list-inline">
												<li class="list-inline-item"><span class="badge bg-secondary badge-pill"><?php echo "Computer Terminal"; ?></span></li>
										    </ul>
									    </div><!--//resume-timeline-item-desc-->

								    </article><!--//resume-timeline-item-->
								    
							    </div><!--//resume-timeline-->
							      
						    </div>
					    </section><!--//projects-section-->
				    </div>
				    <div class="col-lg-3">
					    <section class="resume-section skills-section mb-5">
						    <h2 class="resume-section-title text-uppercase font-weight-bold pb-3 mb-3"><?php echo "Skills &amp; Tools"; ?></h2>
						    <div class="resume-section-content">
						        <div class="resume-skill-item">
							        <ul class="list-unstyled mb-4">  
								        <li class="mb-2">
								            <div class="resume-skill-name"><?php echo "SQL"; ?></div>
									        <div class="progress resume-progress">
											    <div class="progress-bar theme-progress-bar-dark" role="progressbar" style="width: 90%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
											</div>
								        </li>
										<li class="mb-2">
								            <div class="resume-skill-name"> <?php echo "Python"; ?></div>
									        <div class="progress resume-progress">
											    <div class="progress-bar theme-progress-bar-dark" role="progressbar" style="width: 95%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
											</div>
								        </li>
								        <li class="mb-2">
								            <div class="resume-skill-name"><?php echo "HTML/CSS"; ?></div>
									        <div class="progress resume-progress">
											    <div class="progress-bar theme-progress-bar-dark" role="progressbar" style="width: 80%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
											</div>
								        </li>
							        </ul>
						        </div><!--//resume-skill-item-->
						        <div class="resume-skill-item">
						            <h4 class="resume-skills-cat font-weight-bold"><?php echo "Others"; ?></h4>
						            <ul class="list-inline">
							            <li class="list-inline-item"><span class="badge badge-light"><?php echo "Java"; ?></span></li>
							            <li class="list-inline-item"><span class="badge badge-light"><?php echo "JavaScript"; ?></span></li>
										<li class="list-inline-item"><span class="badge badge-light"><?php echo "AWS"; ?></span></li>
										<li class="list-inline-item"><span class="badge badge-light"><?php echo "Apache"; ?></span></li>
						            </ul>
						        </div><!--//resume-skill-item-->
						    </div><!--resume-section-content-->
					    </section><!--//skills-section-->
					    <section class="resume-section education-section mb-5">
						    <h2 class="resume-section-title text-uppercase font-weight-bold pb-3 mb-3"><?php echo "Education"; ?></h2>
						    <div class="resume-section-content">
							    <ul class="list-unstyled">
								    <li class="mb-2">
								        <div class="resume-degree font-weight-bold"><?php echo "BS in College of Informatics"; ?></div>
								        <div class="resume-degree-org"><?php echo "Northern Kentucky University Highland Heights"; ?></div>
								        <div class="resume-degree-time"><?php echo "2020 - Current"; ?></div>
								    </li>
								    <li>
								        <div class="resume-degree font-weight-bold"><?php echo "High School Diploma"; ?></div>
								        <div class="resume-degree-org"><?php echo "St. Henry District High School Erlanger"; ?></div>
								        <div class="resume-degree-time"><?php echo "2016 - 2020"; ?></div>
								    </li>
							    </ul>
						    </div>
					    </section><!--//education-section-->
					    <section class="resume-section reference-section mb-5">
						    <h2 class="resume-section-title text-uppercase font-weight-bold pb-3 mb-3"><?php echo "Awards &amp; Honors"; ?></h2>
						    <div class="resume-section-content">
							    <ul class="list-unstyled resume-awards-list">
									<li class="mb-2 ps-4 position-relative">
								        <i class="resume-award-icon fas fa-trophy position-absolute" data-fa-transform="shrink-2"></i>
								        <div class="resume-award-name"><?php echo "President's List"; ?></div>
								        <div class="resume-award-desc"><?php echo "Fall 2021, Fall 2022 - Spring 2023"; ?></div>
								    </li>
									<li class="mb-2 ps-4 position-relative">
								        <i class="resume-award-icon fas fa-trophy position-absolute" data-fa-transform="shrink-2"></i>
								        <div class="resume-award-name"><?php echo "Dean's List"; ?></div>
								        <div class="resume-award-desc"><?php echo "Fall 2020 - Spring 2021, Spring 2022"; ?></div>
								    </li>
									<li class="mb-2 ps-4 position-relative">
								        <i class="resume-award-icon fas fa-trophy position-absolute" data-fa-transform="shrink-2"></i>
								        <div class="resume-award-name"><?php echo "CSC Department Outstanding Freshmen Award"; ?></div>
								        <div class="resume-award-desc"><?php echo "2020-2021"; ?></div>
								    </li>
								    <li class="mb-2 ps-4 position-relative">
								        <i class="resume-award-icon fas fa-trophy position-absolute" data-fa-transform="shrink-2"></i>
								        <div class="resume-award-name"><?php echo "Academic Excellence: Mathematics Award"; ?></div>
								        <div class="resume-award-desc"><?php echo "September 2019 - Selected by Algebra 2 Teacher."; ?></div>
								    </li>
									<li class="mb-2 ps-4 position-relative">
								        <i class="resume-award-icon fas fa-trophy position-absolute" data-fa-transform="shrink-2"></i>
								        <div class="resume-award-name"><?php echo "Academic Excellence: Mathematics Award"; ?></div>
								        <div class="resume-award-desc"><?php echo "November 2017 - Selected by Basic Algebra Teacher."; ?></div>
								    </li>
									<li class="mb-2 ps-4 position-relative">
								        <i class="resume-award-icon fas fa-trophy position-absolute" data-fa-transform="shrink-2"></i>
								        <div class="resume-award-name"><?php echo "High School Honor Roll"; ?></div>
								        <div class="resume-award-desc"><?php echo "2016 - 2020"; ?></div>
								    </li>
							    </ul>
						    </div>
					    </section><!--//interests-section-->
					    <section class="resume-section language-section mb-5">
						    <h2 class="resume-section-title text-uppercase font-weight-bold pb-3 mb-3"><?php echo "Languages"; ?></h2>
						    <div class="resume-section-content">
							    <ul class="list-unstyled resume-lang-list">
								    <li class="mb-2"><span class="resume-lang-name font-weight-bold"><?php echo "English"; ?></span> <small class="text-muted font-weight-normal"><?php echo "(Native)"; ?></small></li>
							    </ul>
						    </div>
					    </section><!--//language-section-->
					    <section class="resume-section interests-section mb-5">
						    <h2 class="resume-section-title text-uppercase font-weight-bold pb-3 mb-3"><?php echo "Interests"; ?></h2>
						    <div class="resume-section-content">
							    <ul class="list-unstyled">
								    <li class="mb-1"><?php echo "Gardening"; ?></li>
								    <li class="mb-1"><?php echo "Reading"; ?></li>
									<li class="mb-1"><?php echo "Drawing"; ?></li>
								    <li class="mb-1"><?php echo "Baking"; ?></li>
							    </ul>
						    </div>
					    </section><!--//interests-section-->
					    
				    </div>
			    </div><!--//row-->
		    </div><!--//resume-body-->
		    
	    </div>
    </article> 

    
    <footer class="footer text-center pt-2 pb-5">
	    <!--/* This template is free as long as you keep the footer attribution link. If you'd like to use the template without the attribution link, you can buy the commercial license via our website: themes.3rdwavemedia.com Thank you for your support. :) */-->
        <small class="copyright"><?php echo "Designed with "; ?><span class="sr-only"><?php echo "love "; ?></span><i class="fas fa-heart"></i><?php echo " by Maria Wagner"; ?></small>
    </footer>

    

</body>
</html> 

